<?php
/**
 * Generative Canvas block (server side).
 *
 * @package Cyberdeck
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Built-in sketches. Custom sketches registered in JS (cyberdeckGenerative.register) work too:
 * the block accepts any slug of [a-z0-9-], so nothing needs to be listed here for them to run.
 *
 * @return array<string,string> slug => label
 */
function cyberdeck_generative_sketches() {
	return apply_filters(
		'cyberdeck_generative_sketches',
		array(
			'flow'          => 'Flow field',
			'constellation' => 'Constellation',
			'truchet'       => 'Truchet tiles',
			'waves'         => 'Wave lines',
			'glitch'        => 'Glitch grid',
		)
	);
}

function cyberdeck_generative_register_assets() {
	$ver = static function ( $rel ) {
		$path = get_theme_file_path( $rel );
		return file_exists( $path ) ? (string) filemtime( $path ) : '0.5.0';
	};

	wp_register_style( 'cyberdeck-generative', get_theme_file_uri( 'assets/generative/generative.css' ), array(), $ver( 'assets/generative/generative.css' ) );
	wp_register_style( 'cyberdeck-generative-editor', get_theme_file_uri( 'assets/generative/generative-editor.css' ), array( 'cyberdeck-generative' ), $ver( 'assets/generative/generative-editor.css' ) );
	wp_register_script(
		'cyberdeck-generative-view',
		get_theme_file_uri( 'assets/generative/generative.js' ),
		array(),
		$ver( 'assets/generative/generative.js' ),
		array(
			'in_footer' => true,
			'strategy'  => 'defer',
		)
	);
}
add_action( 'init', 'cyberdeck_generative_register_assets', 5 );

/**
 * The editor canvas is an iframe; load the engine into it so the preview animates.
 */
function cyberdeck_generative_editor_assets() {
	if ( is_admin() ) {
		wp_enqueue_script( 'cyberdeck-generative-view' );
	}
}
add_action( 'enqueue_block_assets', 'cyberdeck_generative_editor_assets' );

/**
 * Markup for the block.
 *
 * @param array  $attributes Block attributes.
 * @param string $content    Rendered inner blocks.
 * @return string
 */
function cyberdeck_generative_render( array $attributes, $content ) {
	$pick = static function ( $value, array $allowed, $default ) {
		return in_array( $value, $allowed, true ) ? $value : $default;
	};

	$sketch = isset( $attributes['sketch'] ) && preg_match( '/^[a-z0-9-]{1,40}$/', (string) $attributes['sketch'] ) ? $attributes['sketch'] : 'flow';
	$seed   = isset( $attributes['seed'] ) ? mb_substr( sanitize_text_field( $attributes['seed'] ), 0, 64 ) : 'cyberdeck';
	$mode   = $pick( $attributes['mode'] ?? '', array( 'section', 'fixed' ), 'section' );

	$data = array(
		'data-sketch'      => $sketch,
		'data-seed'        => '' !== $seed ? $seed : 'cyberdeck',
		'data-palette'     => $pick( $attributes['palette'] ?? '', array( 'theme', 'duo', 'primary', 'mono' ), 'theme' ),
		'data-density'     => (string) max( 1, min( 10, (int) ( $attributes['density'] ?? 5 ) ) ),
		'data-speed'       => (string) max( 0, min( 5, (float) ( $attributes['speed'] ?? 1 ) ) ),
		'data-interactive' => ( ! isset( $attributes['interactive'] ) || $attributes['interactive'] ) ? '1' : '0',
		'data-background'  => $pick( $attributes['background'] ?? '', array( 'void', 'transparent' ), 'void' ),
		'data-fps'         => (int) ( $attributes['fps'] ?? 30 ) === 60 ? '60' : '30',
		'data-mode'        => $mode,
	);

	$style = sprintf(
		'--cd-gen-min:%dvh;--cd-gen-dim:%s;',
		max( 20, min( 100, (int) ( $attributes['minHeight'] ?? 70 ) ) ),
		(string) ( max( 0, min( 80, (int) ( $attributes['dim'] ?? 25 ) ) ) / 100 )
	);

	$wrapper = get_block_wrapper_attributes( array_merge( array( 'class' => 'cd-gen is-mode-' . $mode, 'style' => $style ), $data ) );

	$html  = '<div ' . $wrapper . '>';
	$html .= '<canvas class="cd-gen__canvas" aria-hidden="true"></canvas>';
	if ( 'section' === $mode ) {
		$html .= '<div class="cd-gen__content">' . $content . '</div>';
	}
	$html .= '</div>';

	return $html;
}
